export const environment = {
  production: true,
  apiEndPoint: 'http://localhost:3000/api/'
};
